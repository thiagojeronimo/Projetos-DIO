# Workout API – DIO Challenge

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Endpoints

- `GET /atletas` – lista atletas com paginação + filtros `nome`, `cpf`.
- `POST /atletas` – cria atleta (tratamento de CPF duplicado com status 303).
