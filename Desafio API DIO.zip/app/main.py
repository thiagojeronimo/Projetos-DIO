from fastapi import FastAPI
from fastapi_pagination import add_pagination
from .database import engine, Base
from .routers import atletas

app = FastAPI(title="Workout API DIO Challenge")

Base.metadata.create_all(bind=engine)

app.include_router(atletas.router)

add_pagination(app)
