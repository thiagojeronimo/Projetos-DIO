from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from fastapi.responses import JSONResponse
from fastapi_pagination import Page, paginate

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/atletas", tags=["Atletas"])

@router.post("", status_code=201)
def criar_atleta(atleta: schemas.AtletaCreate, db: Session = Depends(get_db)):
    novo = models.Atleta(**atleta.dict())
    db.add(novo)
    try:
        db.commit()
        db.refresh(novo)
    except IntegrityError:
        db.rollback()
        return JSONResponse(
            status_code=303,
            content={"detail": f"Já existe um atleta cadastrado com o cpf: {atleta.cpf}"}
        )
    return novo

@router.get("", response_model=Page[schemas.AtletaResponse])
def listar_atletas(
    nome: str = Query(None),
    cpf: str = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(models.Atleta)
    if nome:
        query = query.filter(models.Atleta.nome.ilike(f"%{nome}%"))
    if cpf:
        query = query.filter(models.Atleta.cpf == cpf)
    return paginate(query.all())
